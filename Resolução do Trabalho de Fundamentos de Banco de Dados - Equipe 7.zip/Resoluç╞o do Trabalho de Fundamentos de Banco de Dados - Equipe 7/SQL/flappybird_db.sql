-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Tempo de geração: 03/01/2026 às 19:33
-- Versão do servidor: 8.4.7
-- Versão do PHP: 8.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `flappybird_db`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `cenario`
--

DROP TABLE IF EXISTS `cenario`;
CREATE TABLE IF NOT EXISTS `cenario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome_cenario` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dificuldade` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `cenario`
--

INSERT INTO `cenario` (`id`, `nome_cenario`, `dificuldade`) VALUES
(1, 'Dia Ensolarado', 'Padrão');

-- --------------------------------------------------------

--
-- Estrutura para tabela `inventario`
--

DROP TABLE IF EXISTS `inventario`;
CREATE TABLE IF NOT EXISTS `inventario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `jogador_id` int NOT NULL,
  `item_id` int NOT NULL,
  `data_aquisicao` datetime DEFAULT CURRENT_TIMESTAMP,
  `equipado` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `jogador_id` (`jogador_id`),
  KEY `item_id` (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `inventario`
--

INSERT INTO `inventario` (`id`, `jogador_id`, `item_id`, `data_aquisicao`, `equipado`) VALUES
(1, 1, 3, '2026-01-02 21:56:27', 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `item`
--

DROP TABLE IF EXISTS `item`;
CREATE TABLE IF NOT EXISTS `item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `preco` float NOT NULL,
  `efeito` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `item`
--

INSERT INTO `item` (`id`, `nome`, `tipo`, `preco`, `efeito`) VALUES
(1, 'Ghost', 'Habilidade', 50, 'Atravessa paredes'),
(2, 'Shield', 'Habilidade', 100, 'Protege colisão'),
(3, 'TimeSlow', 'Habilidade', 30, 'Câmera lenta'),
(4, 'Shrink', 'Habilidade', 40, 'Diminui tamanho');

-- --------------------------------------------------------

--
-- Estrutura para tabela `jogador`
--

DROP TABLE IF EXISTS `jogador`;
CREATE TABLE IF NOT EXISTS `jogador` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nickname` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `senha` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cadastro` datetime DEFAULT CURRENT_TIMESTAMP,
  `ranking_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nickname` (`nickname`),
  KEY `fk_jogador_ranking` (`ranking_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `jogador`
--

INSERT INTO `jogador` (`id`, `nickname`, `senha`, `data_cadastro`, `ranking_id`) VALUES
(1, '123', '$2y$10$X5O3pDQ2JsZ0zXkIykyEn.vxE513/9lgH6CaywJeywE7YNXkO..XG', '2026-01-02 15:40:39', 1),
(2, 'aline666', '$2y$10$FApWZnO5LJy5uWdCweqj0OWOVphS/0wTQ1L.qSGEuv6PDWucN80p2', '2026-01-03 15:10:47', 3);

-- --------------------------------------------------------

--
-- Estrutura para tabela `partida`
--

DROP TABLE IF EXISTS `partida`;
CREATE TABLE IF NOT EXISTS `partida` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data_hora` datetime DEFAULT CURRENT_TIMESTAMP,
  `pontuacao` int NOT NULL,
  `tempo_duracao` time DEFAULT NULL,
  `jogador_id` int NOT NULL,
  `cenario_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jogador_id` (`jogador_id`),
  KEY `cenario_id` (`cenario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `partida`
--

INSERT INTO `partida` (`id`, `data_hora`, `pontuacao`, `tempo_duracao`, `jogador_id`, `cenario_id`) VALUES
(1, '2026-01-02 21:52:43', 14, '00:00:17', 1, 1),
(2, '2026-01-02 21:55:23', 8, '00:00:11', 1, 1),
(3, '2026-01-02 21:55:45', 6, '00:00:09', 1, 1),
(4, '2026-01-02 21:56:22', 23, '00:00:25', 1, 1),
(5, '2026-01-02 21:56:48', 13, '00:00:15', 1, 1),
(6, '2026-01-02 21:56:48', 13, '00:00:16', 1, 1),
(9, '2026-01-03 15:31:35', 47, '00:00:50', 2, 1),
(17, '2026-01-03 15:56:33', 6, '00:00:09', 2, 1),
(18, '2026-01-03 15:57:17', 36, '00:00:38', 2, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `ranking`
--

DROP TABLE IF EXISTS `ranking`;
CREATE TABLE IF NOT EXISTS `ranking` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome_patente` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pontuacao_minima` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `ranking`
--

INSERT INTO `ranking` (`id`, `nome_patente`, `pontuacao_minima`) VALUES
(1, 'Iniciante', 0),
(2, 'Aprendiz', 20),
(3, 'Veterano', 50),
(4, 'Mestre', 100),
(5, 'Lenda Flappy', 200);

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `inventario`
--
ALTER TABLE `inventario`
  ADD CONSTRAINT `inventario_ibfk_1` FOREIGN KEY (`jogador_id`) REFERENCES `jogador` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `inventario_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `item` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Restrições para tabelas `jogador`
--
ALTER TABLE `jogador`
  ADD CONSTRAINT `fk_jogador_ranking` FOREIGN KEY (`ranking_id`) REFERENCES `ranking` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Restrições para tabelas `partida`
--
ALTER TABLE `partida`
  ADD CONSTRAINT `partida_ibfk_1` FOREIGN KEY (`jogador_id`) REFERENCES `jogador` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `partida_ibfk_2` FOREIGN KEY (`cenario_id`) REFERENCES `cenario` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
