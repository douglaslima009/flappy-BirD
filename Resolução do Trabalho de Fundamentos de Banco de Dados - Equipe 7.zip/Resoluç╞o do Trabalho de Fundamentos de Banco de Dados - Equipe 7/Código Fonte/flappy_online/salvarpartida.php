<?php
require_once 'conexao.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Recebe os dados enviados pelo Unity.
    $jogador_id = $_POST['jogador_id'] ?? 0;
    $pontuacao = $_POST['pontuacao'] ?? 0;
    $tempo = $_POST['tempo'] ?? '00:00:00';
    $cenario_id = 1;

    if ($jogador_id > 0) {
        // 1. Insere a nova partida no banco.
        $sql = "INSERT INTO partida (jogador_id, pontuacao, tempo_duracao, cenario_id, data_hora) VALUES (?, ?, ?, ?, NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iisi", $jogador_id, $pontuacao, $tempo, $cenario_id);
        
        if ($stmt->execute()) {
            // Lógica do Ranking.
            // Passo 1: Calcula a pontuação TOTAL do jogador (Soma de todas as partidas).
            $sqlSoma = "SELECT SUM(pontuacao) as total FROM partida WHERE jogador_id = ?";
            $stmtSoma = $conn->prepare($sqlSoma);
            $stmtSoma->bind_param("i", $jogador_id);
            $stmtSoma->execute();
            $resSoma = $stmtSoma->get_result();
            $rowSoma = $resSoma->fetch_assoc();
            $totalPontos = $rowSoma['total'];

            // Passo 2: Descobre qual a maior patente que essa pontuação alcança.
            $sqlRank = "SELECT id FROM ranking WHERE pontuacao_minima <= ? ORDER BY pontuacao_minima DESC LIMIT 1";
            $stmtRank = $conn->prepare($sqlRank);
            $stmtRank->bind_param("i", $totalPontos);
            $stmtRank->execute();
            $resRank = $stmtRank->get_result();

            if ($rowRank = $resRank->fetch_assoc()) {
                $novoRankingId = $rowRank['id'];

                // Passo 3: Atualiza a patente do jogador na tabela 'jogador'.
                $sqlUpdate = "UPDATE jogador SET ranking_id = ? WHERE id = ?";
                $stmtUpdate = $conn->prepare($sqlUpdate);
                $stmtUpdate->bind_param("ii", $novoRankingId, $jogador_id);
                $stmtUpdate->execute();
            }

            echo json_encode(["sucesso" => true, "mensagem" => "Partida salva e ranking atualizado!"]);
        } else {
            echo json_encode(["sucesso" => false, "mensagem" => "Erro ao salvar no banco: " . $stmt->error]);
        }
    } else {
        echo json_encode(["sucesso" => false, "mensagem" => "ID do jogador inválido."]);
    }
} else {
    echo json_encode(["sucesso" => false, "mensagem" => "Método inválido. Use POST."]);
}
?>