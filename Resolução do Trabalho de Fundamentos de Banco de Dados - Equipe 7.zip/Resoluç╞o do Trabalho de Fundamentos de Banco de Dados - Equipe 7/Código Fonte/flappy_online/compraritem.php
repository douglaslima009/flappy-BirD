<?php
require_once 'conexao.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $jogador_id = $_POST['jogador_id'] ?? 0;
    $item_id = $_POST['item_id'] ?? 0; // ID do ItemData (Configurado no Manager dentro do Unity).

    // Verifica se já tem o item para não duplicar.
    $sqlCheck = "SELECT id FROM inventario WHERE jogador_id = ? AND item_id = ?";
    $stmtCheck = $conn->prepare($sqlCheck);
    $stmtCheck->bind_param("ii", $jogador_id, $item_id);
    $stmtCheck->execute();
    $resultCheck = $stmtCheck->get_result();

    if ($resultCheck->num_rows == 0) {
        $sql = "INSERT INTO inventario (jogador_id, item_id, data_aquisicao, equipado) VALUES (?, ?, NOW(), 0)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $jogador_id, $item_id);

        if ($stmt->execute()) {
            echo json_encode(["sucesso" => true, "mensagem" => "Item comprado com sucesso!"]);
        } else {
            echo json_encode(["sucesso" => false, "mensagem" => "Erro no banco: " . $stmt->error]);
        }
    } else {
        echo json_encode(["sucesso" => true, "mensagem" => "Item já possuído (sem erro)."]);
    }

} else {
    echo json_encode(["sucesso" => false, "mensagem" => "Método inválido."]);
}
?>