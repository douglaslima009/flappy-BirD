<?php
session_start();
require_once 'conexao.php';

$msgErro = "";

if (isset($_SESSION['usuario_id'])) {
    header("Location: jogo.php");
    exit;
}

// Processamento do login.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nick = trim($_POST['nickInput'] ?? '');
    $senha = $_POST['passInput'] ?? '';

    if (empty($nick) || empty($senha)) {
        $msgErro = "Preencha todos os campos.";
    } else {
        $sql = "SELECT id, nickname, senha FROM jogador WHERE nickname = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $nick);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($user = $resultado->fetch_assoc()) {
            if (password_verify($senha, $user['senha'])) {
                // Login Sucesso! Cria a sessão.
                $_SESSION['usuario_id'] = $user['id'];
                $_SESSION['usuario_nick'] = $user['nickname'];
                
                header("Location: jogo.php");
                exit;
            } else {
                $msgErro = "Senha incorreta.";
            }
        } else {
            $msgErro = "Usuário não encontrado.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Flappy BirD!</title>
    <link rel="icon" href="logo.png" type="image/png"> <style>
        body {
            margin: 0; padding: 0;
            background-color: #70c5ce;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex; justify-content: center; align-items: center;
            height: 100vh; overflow: hidden;
        }

        .game-card {
            background-color: #ded895;
            border: 4px solid #543847;
            border-radius: 15px;
            padding: 30px;
            width: 350px;
            text-align: center;
            box-shadow: 0 10px 0 #543847;
        }

        .logo-img {
            display: block;
            margin-left: 10px;
            margin-right: 0;
            max-width: 100%;
            height: auto;
            filter: drop-shadow(3px 3px 0 #543847);
        }

        .input-group { margin-bottom: 15px; text-align: left; }
        label { display: block; font-weight: bold; color: #543847; margin-bottom: 5px; text-transform: uppercase; font-size: 0.8em; }
        
        .password-wrapper { position: relative; width: 100%; }
        
        input {
            width: 100%; padding: 12px; padding-right: 40px;
            border: 3px solid #543847; border-radius: 8px;
            box-sizing: border-box; outline: none; font-size: 16px; 
        }

        .toggle-btn {
            position: absolute; right: 10px; top: 50%;
            transform: translateY(-50%); cursor: pointer;
            width: 24px; height: 24px; background: none; border: none; padding: 0;
            display: flex; align-items: center; justify-content: center;
        }
        
        .toggle-btn svg { width: 20px; height: 20px; fill: #543847; transition: opacity 0.2s; }
        .toggle-btn:hover svg { opacity: 0.7; }

        button {
            background-color: #e86101; color: white;
            border: 3px solid #543847; border-radius: 8px;
            padding: 15px 20px; font-size: 18px; font-weight: bold;
            cursor: pointer; width: 100%;
            box-shadow: 0 5px 0 #a04500; transition: all 0.1s ease;
            text-transform: uppercase;
        }

        button:hover { background-color: #ff7b1a; transform: scale(1.03); box-shadow: 0 7px 0 #a04500; }
        button:active { box-shadow: 0 2px 0 #a04500; transform: translateY(4px) scale(1.0); }

        .footer-text { margin-top: 20px; color: #543847; font-size: 0.9em; font-weight: bold; }
        .footer-text a { color: #e86101; text-decoration: none; }
        .ground { position: absolute; bottom: 0; width: 100%; height: 60px; background-color: #73bf2e; border-top: 6px solid #543847; }
        
        .hide { display: none; }
        .error-msg {
            color: #d8000c; background-color: #ffbaba;
            border: 1px solid #d8000c; margin-bottom: 15px;
            padding: 10px; border-radius: 5px; font-size: 0.9em; font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="game-card">
        <img src="logo.png" alt="Logo" class="logo-img">
        
        <?php if(!empty($msgErro)): ?>
            <div class="error-msg"><?php echo $msgErro; ?></div>
        <?php endif; ?>

        <form action="index.php" method="POST" id="loginForm" onsubmit="validarFormulario(event)">
            <div class="input-group">
                <label>Nickname:</label>
                <input type="text" id="nickInput" name="nickInput" placeholder="Seu nome de usuário">
            </div>
            
            <div class="input-group">
                <label>Senha:</label>
                <div class="password-wrapper">
                    <input type="password" id="passInput" name="passInput" placeholder="Sua senha">
                    <div class="toggle-btn" onclick="togglePassword()">
                        <svg id="eyeClosed" viewBox="0 0 24 24">
                            <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
                        </svg>
                        <svg id="eyeOpen" class="hide" viewBox="0 0 24 24">
                            <path d="M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.43-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7zM2 4.27l2.28 2.28.46.46C3.08 8.3 1.78 10.02 1 12c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3 2 4.27zM7.53 9.8l1.55 1.55c-.05.21-.08.43-.08.65 0 1.66 1.34 3 3 3 .22 0 .44-.03.65-.08l1.55 1.55c-.67.33-1.41.53-2.2.53-2.76 0-5-2.24-5-5 0-.79.2-1.53.53-2.2zm4.31-.78l3.15 3.15.02-.16c0-1.66-1.34-3-3-3l-.17.01z"/>
                        </svg>
                    </div>
                </div>
            </div>

            <button type="submit">Entrar e Jogar</button>
        </form>

        <div class="footer-text">
            Novo por aqui? <a href="cadastro.php">Crie sua conta</a>
        </div>
    </div>
    <div class="ground"></div>

    <script>
        function togglePassword() {
            const input = document.getElementById('passInput');
            const eyeOpen = document.getElementById('eyeOpen');
            const eyeClosed = document.getElementById('eyeClosed');

            if (input.type === "password") {
                input.type = "text";
                eyeOpen.classList.add('hide');
                eyeClosed.classList.remove('hide');
            } else {
                input.type = "password";
                eyeOpen.classList.remove('hide');
                eyeClosed.classList.add('hide');
            }
        }

        function validarFormulario(event) {
            // Se o Javascript falhar, o PHP trata. 
            const nickInput = document.getElementById('nickInput');
            const passInput = document.getElementById('passInput');
            
            const nick = nickInput.value;
            const pass = passInput.value;

            const nickLimpo = nick.replace(/\s/g, ''); 
            const passLimpo = pass.replace(/\s/g, '');

            let msgErro = "";

            if (nickLimpo.length === 0 || passLimpo.length === 0) {
                msgErro = "Nick e Senha são obrigatórios!";
            } else if (nickLimpo.length < 3) {
                msgErro = "O Nick deve ter pelo menos 3 caracteres.";
            } else if (passLimpo.length < 6) {
                msgErro = "A Senha deve ter pelo menos 6 caracteres.";
            }

            if (msgErro !== "") {
                event.preventDefault(); 
                alert(msgErro); 
                return false;
            }
            return true;
        }
    </script>
</body>
</html>