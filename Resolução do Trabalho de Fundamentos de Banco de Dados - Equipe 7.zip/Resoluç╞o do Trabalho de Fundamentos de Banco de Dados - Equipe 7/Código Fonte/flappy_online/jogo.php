<?php
session_start();
require_once 'conexao.php';

if (!isset($_SESSION['usuario_id'])) {
    header("Location: index.php");
    exit;
}

$idUsuario = $_SESSION['usuario_id'];

// Busca os dados.
$sql = "SELECT j.nickname, r.nome_patente 
        FROM jogador j 
        JOIN ranking r ON j.ranking_id = r.id 
        WHERE j.id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $idUsuario);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado->num_rows > 0) {
    $dados = $resultado->fetch_assoc();
    $nickname = $dados['nickname'];
    $patente = $dados['nome_patente'];
} else {
    $nickname = "Jogador";
    $patente = "Desconhecido";
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Flappy BirD!</title>
    <link rel="icon" href="logo.png" type="image/png">
    <style>
        body {
            margin: 0; padding: 0;
            background-color: #70c5ce;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex; justify-content: center; align-items: center;
            min-height: 100vh; 
            overflow-x: hidden;
            padding-bottom: 80px; 
        }

        .game-card {
            background-color: #ded895;
            border: 4px solid #543847;
            border-radius: 15px;
            padding: 30px;
            width: 85%; max-width: 1024px; min-height: 70vh;
            display: flex; flex-direction: column; align-items: center; justify-content: center;
            text-align: center;
            box-shadow: 0 10px 0 #543847;
            box-sizing: border-box;
            margin-bottom: 100px; margin-top: 20px;
            position: relative; z-index: 10;
        }

        .logo-img { display: block; margin-bottom: 10px; max-width: 200px; height: auto; filter: drop-shadow(3px 3px 0 #543847); }
        h2 { color: #543847; margin: 10px 0; text-transform: uppercase; }
        p { color: #543847; font-weight: bold; font-size: 1.1em; }
        
        .badge {
            background-color: #e86101; color: white; padding: 5px 10px;
            border-radius: 5px; border: 2px solid #543847;
            display: inline-block; margin-top: 5px; margin-bottom: 20px;
        }

        /* Container do Unity. */
        #unity-container { 
            width: 100%; max-width: 960px; aspect-ratio: 16/9; position: relative; 
            background: #231F20; border: 4px solid #543847; border-radius: 10px;
            overflow: hidden;
        }
        #unity-canvas { width: 100%; height: 100%; }
        #unity-loading-bar { position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%); display: none; }
        #unity-progress-bar-empty { width: 141px; height: 18px; margin-top: 10px; margin-left: 6.5px; background: url('TemplateData/progress-bar-empty-dark.png') no-repeat center; }
        #unity-progress-bar-full { width: 0%; height: 18px; margin-top: 10px; background: url('TemplateData/progress-bar-full-dark.png') no-repeat center; }

        .btn-sair {
            display: inline-block; margin-top: 30px;
            background: #d8000c; color: white;
            border: 3px solid #543847; border-radius: 8px;
            padding: 10px 30px; font-size: 18px; font-weight: bold;
            cursor: pointer; text-decoration: none;
            box-shadow: 0 5px 0 #8a0008; transition: transform 0.1s;
        }
        .btn-sair:active { transform: translateY(4px); box-shadow: 0 2px 0 #8a0008; }

        .btn-delete {
            margin-top: 15px; font-size: 0.8em; color: #b00000;
            cursor: pointer; text-decoration: underline; background: none; border: none;
        }
        .btn-delete:hover { color: red; }

        .ground { position: fixed; bottom: 0; left: 0; width: 100%; height: 60px; background-color: #73bf2e; border-top: 6px solid #543847; z-index: 100; pointer-events: none; }

        .modal-overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.7); z-index: 200;
            display: none; align-items: center; justify-content: center;
        }
        .modal-box {
            background: #ded895; border: 4px solid #543847; border-radius: 10px;
            padding: 20px; width: 90%; max-width: 400px; text-align: center;
        }
        .modal-box h3 { color: #d8000c; text-transform: uppercase; margin-top: 0; }
        .modal-box input {
            width: 100%; padding: 10px; margin: 15px 0;
            border: 2px solid #543847; border-radius: 5px; box-sizing: border-box;
        }
        .modal-btn-confirm {
            background: #d8000c; color: white; border: 2px solid #543847;
            padding: 10px 20px; border-radius: 5px; font-weight: bold; cursor: pointer;
        }
        .modal-btn-cancel {
            background: #ccc; color: #333; border: 2px solid #543847;
            padding: 10px 20px; border-radius: 5px; font-weight: bold; cursor: pointer; margin-left: 10px;
        }
    </style>
</head>
<body>
    <div class="game-card">
        <img src="logo.png" alt="Logo" class="logo-img">
        
        <h2>Bem-vindo, <?php echo htmlspecialchars($nickname); ?>!</h2>
        <p>Sua Patente Atual: <span class="badge"><?php echo htmlspecialchars($patente); ?></span></p>

        <div id="unity-container">
            <canvas id="unity-canvas" width=960 height=600 tabindex="-1"></canvas>
            <div id="unity-loading-bar">
                <div id="unity-logo"></div>
                <div id="unity-progress-bar-empty">
                    <div id="unity-progress-bar-full"></div>
                </div>
            </div>
        </div>

        <a href="logout.php" class="btn-sair">SAIR / LOGOUT</a>
        
        <button class="btn-sair" onclick="abrirModal()">EXCLUIR MINHA CONTA</button>
    </div>
    <div class="ground"></div>

    <div id="modalExcluir" class="modal-overlay">
        <div class="modal-box">
            <h3>Tem certeza?</h3>
            <p>Isso apagará todo seu histórico e itens. Digite sua senha para confirmar:</p>
            <input type="password" id="senhaExclusao" placeholder="Sua senha atual">
            <br>
            <button class="modal-btn-confirm" onclick="confirmarExclusao()">EXCLUIR TUDO</button>
            <button class="modal-btn-cancel" onclick="fecharModal()">Cancelar</button>
        </div>
    </div>

    <script>
      // Lógica do Unity WebGL.
      var container = document.querySelector("#unity-container");
      var canvas = document.querySelector("#unity-canvas");
      var loadingBar = document.querySelector("#unity-loading-bar");
      var progressBarFull = document.querySelector("#unity-progress-bar-full");

      var buildUrl = "Build";
      var loaderUrl = buildUrl + "/BuildWebGL.loader.js"; 
      var config = {
        dataUrl: buildUrl + "/BuildWebGL.data",
        frameworkUrl: buildUrl + "/BuildWebGL.framework.js",
        codeUrl: buildUrl + "/BuildWebGL.wasm",
        streamingAssetsUrl: "StreamingAssets",
        companyName: "DefaultCompany",
        productName: "FlappyBird",
        productVersion: "1.0",
        captureAllKeyboardInput: false,
      };

      var idDoJogadorPHP = <?php echo $idUsuario; ?>;
      var script = document.createElement("script");
      script.src = loaderUrl;
      script.onload = () => {
        createUnityInstance(canvas, config, (progress) => {
          progressBarFull.style.width = 100 * progress + "%";
        }).then((unityInstance) => {
          loadingBar.style.display = "none";
          // Envia o ID do objeto criado na cena do Unity.
          unityInstance.SendMessage("NetworkManager", "DefinirIDJogador", idDoJogadorPHP);
        }).catch((message) => { alert(message); });
      };
      document.body.appendChild(script);

      function abrirModal() {
          document.getElementById('modalExcluir').style.display = 'flex';
      }

      function fecharModal() {
          document.getElementById('modalExcluir').style.display = 'none';
          document.getElementById('senhaExclusao').value = ''; // Limpa senha
      }

      function confirmarExclusao() {
          const senha = document.getElementById('senhaExclusao').value;
          if (!senha) {
              alert("Por favor, digite sua senha.");
              return;
          }

          if (!confirm("Última chance: Isso não pode ser desfeito. Continuar?")) {
              return;
          }

          // FETCH (AJAX)
          const formData = new FormData();
          formData.append('senha', senha);

          fetch('excluirconta.php', {
              method: 'POST',
              body: formData
          })
          .then(response => response.json())
          .then(data => {
              if (data.sucesso) {
                  alert("Conta excluída. Esperamos te ver de volta!");
                  window.location.href = 'index.php';
              } else {
                  alert("Erro: " + data.mensagem);
              }
          })
          .catch(error => {
              console.error('Erro:', error);
              alert("Erro ao conectar com o servidor.");
          });
      }
    </script>
</body>
</html>