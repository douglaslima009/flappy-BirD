<?php
$host = 'localhost';
$usuario = 'root';
$senha = '';
$banco = 'flappybird_db';
$porta = 3308;

$conn = new mysqli($host, $usuario, $senha, $banco, $porta);

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
?>