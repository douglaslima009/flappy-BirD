<?php
session_start();
require_once 'conexao.php';

header('Content-Type: application/json');

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(["sucesso" => false, "mensagem" => "Usuário não logado."]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idUsuario = $_SESSION['usuario_id'];
    $senhaInformada = $_POST['senha'] ?? '';

    if (empty($senhaInformada)) {
        echo json_encode(["sucesso" => false, "mensagem" => "Digite sua senha para confirmar."]);
        exit;
    }

    // Busca a senha criptografada (hash) no banco para conferir.
    $sql = "SELECT senha FROM jogador WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $idUsuario);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        // Verifica se a senha bate
        if (password_verify($senhaInformada, $row['senha'])) {
            
            // 1. Apaga o Inventário do jogador.
            $delInv = $conn->prepare("DELETE FROM inventario WHERE jogador_id = ?");
            $delInv->bind_param("i", $idUsuario);
            $delInv->execute();

            // 2. Apaga as Partidas do jogador.
            $delPartida = $conn->prepare("DELETE FROM partida WHERE jogador_id = ?");
            $delPartida->bind_param("i", $idUsuario);
            $delPartida->execute();

            // 3. Apaga o Jogador.
            $delUser = $conn->prepare("DELETE FROM jogador WHERE id = ?");
            $delUser->bind_param("i", $idUsuario);
            
            if ($delUser->execute()) {
                // Destroi a sessão e desloga.
                session_destroy();
                echo json_encode(["sucesso" => true, "mensagem" => "Conta excluída com sucesso."]);
            } else {
                echo json_encode(["sucesso" => false, "mensagem" => "Erro ao excluir conta: " . $conn->error]);
            }

        } else {
            echo json_encode(["sucesso" => false, "mensagem" => "Senha incorreta!"]);
        }
    } else {
        echo json_encode(["sucesso" => false, "mensagem" => "Usuário não encontrado."]);
    }
}
?>