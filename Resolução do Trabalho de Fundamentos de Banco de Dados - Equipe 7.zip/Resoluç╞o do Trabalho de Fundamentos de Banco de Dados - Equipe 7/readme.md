# Trabalho Final - Fundamentos de Banco de Dados (UFC Russas)
## Projeto: Flappy Bird Online (Integração Unity WebGL + MySQL)

Este trabalho consiste no desenvolvimento de um jogo online integrado a um banco de dados relacional, demonstrando a aplicação prática de modelagem de dados, SQL e integração com sistemas web (PHP).

O sistema permite que jogadores criem contas, salvem seu progresso (pontuação), comprem itens em uma loja virtual (inventário) e subam de patente em um ranking global.

### 👥 Equipe
* **Douglas Lima Menezes** (Matrícula: 552590)
* **Francisco Wandallis Pereira de Sousa** (Matrícula: 553083)
* **Fernando Freitas Dantas** (Matrícula: 561531)
* **Milena de Santiago Maia Costa** (Matrícula: 552981)
* **José Lucas Loureiro Gonçalves** (Matrícula: 561533)

---

### 📂 Estrutura dos Arquivos

A entrega está organizada em três diretórios principais, conforme os requisitos do trabalho:

#### **1. Modelagem**

Contém os diagramas que representam a estrutura do banco de dados.
* `Diagrama_Conceitual.png`: Modelo Entidade-Relacionamento (nível conceitual).
* `Diagrama_Logico.png`: Modelo Relacional gerado via engenharia reversa (nível lógico), exibindo chaves primárias, estrangeiras e tipos de dados.

#### **2. SQL**

Contém o script necessário para instanciar o banco de dados.
* `script_banco_completo.sql`: Arquivo contendo os comandos DDL (criação de tabelas e relacionamentos) e DML (população inicial de itens da loja, patentes do ranking e dados de teste).

#### **3. Codigo_Fonte**

Contém a aplicação completa (Backend e Frontend).
* **Arquivos PHP:** Scripts de conexão, lógica de CRUD (Cadastro, Login, Atualização de Ranking, Exclusão de Conta) e APIs para comunicação com o jogo.
* **Pasta `Build`:** O jogo "Flappy Bird" compilado em WebGL para rodar diretamente no navegador.
* `Relatorios_SQL.txt`: Arquivo de texto contendo os 3 comandos de relatório obrigatórios (JOIN, SUM e WHERE) utilizados no sistema.

---

### 🚀 Funcionalidades Implementadas (CRUD)

O sistema atende aos requisitos de CRUD (Create, Read, Update, Delete) da seguinte forma:

1.  **Create (Criação):** Cadastro de novos jogadores (`cadastro.php`) e inserção de novas partidas/compras.
2.  **Read (Leitura):** Sistema de Login (`index.php`), visualização de Patente e Inventário na tela do jogo.
3.  **Update (Atualização):** Atualização automática da Patente do jogador baseada na pontuação total acumulada (`salvar_partida.php`).
4.  **Delete (Exclusão):** Funcionalidade de "Excluir Minha Conta", que remove o jogador e todos os seus dados vinculados (inventário e histórico de partidas) do banco (`excluir_conta.php`).

---

### ⚙️ Como Rodar o Projeto

1.  Instale um servidor local (WAMP, XAMPP ou similar).
2.  No **phpMyAdmin**, crie um banco de dados chamado `flappybird_db`.
3.  Importe o arquivo localizado na pasta `2. SQL` para criar as tabelas.
4.  Copie o conteúdo da pasta `3. Codigo_Fonte` para o diretório público do seu servidor (ex: `www` ou `htdocs`).
5.  Acesse `http://localhost/seu_projeto/index.php` no navegador.

---